# Keystrokes 2.0

A virtual on-screen keyboard with dwell-click functionality, built in React.

### Features
- Floating draggable keyboard
- Dwell click with adjustable delay
- Click sound feedback
- Global dwell-click support (on buttons, links, etc.)
- Toolbar with right-click and double-click simulation
- Persistent dwell settings with localStorage

---

Created as an assistive tool for users with limited motor function.
