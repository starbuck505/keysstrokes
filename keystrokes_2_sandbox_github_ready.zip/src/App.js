// Keystrokes 2.0 - Now with Toolbar, Feedback, and Settings Memory

import React, { useState, useEffect, useRef } from "react";

const Button = ({ children, ...props }) => (
  <button
    {...props}
    style={{
      background: "#3B82F6",
      color: "#fff",
      padding: "6px 12px",
      borderRadius: "8px",
      marginBottom: "8px",
      border: "none"
    }}
  >
    {children}
  </button>
);

const clickSound = new Audio("https://actions.google.com/sounds/v1/alarms/beep_short.ogg");

export default function App() {
  const [visible, setVisible] = useState(true);
  const [toolbarVisible, setToolbarVisible] = useState(true);
  const [dwellEnabled, setDwellEnabled] = useState(true);
  const [dwellKey, setDwellKey] = useState(null);
  const [timer, setTimer] = useState(null);
  const [position, setPosition] = useState({ x: 50, y: 50 });
  const [dragging, setDragging] = useState(false);
  const [offset, setOffset] = useState({ x: 0, y: 0 });
  const [dwellTime, setDwellTime] = useState(() => {
    return parseInt(localStorage.getItem("dwellTime")) || 500;
  });
  const [output, setOutput] = useState("");

  const ref = useRef();

  const keys = [
    ["Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P"],
    ["A", "S", "D", "F", "G", "H", "J", "K", "L"],
    ["Z", "X", "C", "V", "B", "N", "M"],
    ["Space", "Back"]
  ];

  useEffect(() => {
    localStorage.setItem("dwellTime", dwellTime);
  }, [dwellTime]);

  const playClick = () => {
    clickSound.currentTime = 0;
    clickSound.play();
  };

  const handleMouseEnter = (key) => {
    if (!dwellEnabled) return;
    if (timer) clearTimeout(timer);
    setDwellKey(key);
    setTimer(
      setTimeout(() => {
        handleKeyClick(key);
        playClick();
      }, dwellTime)
    );
  };

  const handleMouseLeave = () => {
    if (timer) clearTimeout(timer);
    setDwellKey(null);
  };

  const handleKeyClick = (key) => {
    if (key === "Back") {
      setOutput((prev) => prev.slice(0, -1));
    } else if (key === "Space") {
      setOutput((prev) => prev + " ");
    } else {
      setOutput((prev) => prev + key);
    }
  };

  const handleMouseDown = (e) => {
    setDragging(true);
    setOffset({
      x: e.clientX - position.x,
      y: e.clientY - position.y
    });
  };

  const handleMouseMove = (e) => {
    if (dragging) {
      setPosition({ x: e.clientX - offset.x, y: e.clientY - offset.y });
    }
  };

  const handleMouseUp = () => {
    setDragging(false);
  };

  // Global dwell click
  useEffect(() => {
    let globalTimer = null;
    let currentElement = null;

    const handleGlobalMouseOver = (e) => {
      if (!dwellEnabled || e.target.closest(".virtual-key")) return;
      if (globalTimer) clearTimeout(globalTimer);
      currentElement = e.target;

      globalTimer = setTimeout(() => {
        if (currentElement && typeof currentElement.click === "function") {
          playClick();
          currentElement.click();
        }
      }, dwellTime);
    };

    const handleGlobalMouseOut = () => {
      if (globalTimer) clearTimeout(globalTimer);
      currentElement = null;
    };

    document.addEventListener("mouseover", handleGlobalMouseOver);
    document.addEventListener("mouseout", handleGlobalMouseOut);
    document.addEventListener("mousemove", handleMouseMove);
    document.addEventListener("mouseup", handleMouseUp);

    return () => {
      document.removeEventListener("mouseover", handleGlobalMouseOver);
      document.removeEventListener("mouseout", handleGlobalMouseOut);
      document.removeEventListener("mousemove", handleMouseMove);
      document.removeEventListener("mouseup", handleMouseUp);
    };
  }, [dwellTime, dwellEnabled]);

  const simulateRightClick = () => {
    const event = new MouseEvent("contextmenu", { bubbles: true, cancelable: true, view: window });
    document.elementFromPoint(position.x + 150, position.y)?.dispatchEvent(event);
    playClick();
  };

  const simulateDoubleClick = () => {
    const target = document.elementFromPoint(position.x + 150, position.y);
    if (target) {
      target.dispatchEvent(new MouseEvent("dblclick", { bubbles: true, cancelable: true, view: window }));
      playClick();
    }
  };

  return (
    <div>
      <div style={{ padding: "16px" }}>
        <label>Output:</label>
        <textarea
          style={{ width: "100%", height: "100px", padding: "8px", marginTop: "4px", borderRadius: "6px", border: "1px solid #ccc" }}
          value={output}
          readOnly
        />
        <div style={{ marginTop: "8px" }}>
          <label>Dwell Time (ms):</label>
          <input
            type="number"
            value={dwellTime}
            onChange={(e) => setDwellTime(parseInt(e.target.value))}
            style={{ marginLeft: "8px", padding: "4px", width: "80px" }}
          />
        </div>
      </div>

      <div
        className="virtual-key"
        onMouseDown={handleMouseDown}
        ref={ref}
        style={{
          position: "fixed",
          left: position.x,
          top: position.y,
          padding: "16px",
          backgroundColor: "#fff",
          borderRadius: "16px",
          boxShadow: "0 4px 16px rgba(0,0,0,0.1)",
          zIndex: 9999
        }}
      >
        <Button onClick={() => setVisible(!visible)}>{visible ? "Hide Keyboard" : "Show Keyboard"}</Button>
        <Button onClick={() => setToolbarVisible(!toolbarVisible)}>{toolbarVisible ? "Hide Toolbar" : "Show Toolbar"}</Button>

        {toolbarVisible && (
          <div style={{ display: "flex", gap: "6px", marginBottom: "12px" }}>
            <Button onClick={() => setDwellEnabled(!dwellEnabled)}>
              {dwellEnabled ? "Dwell ON" : "Dwell OFF"}
            </Button>
            <Button onClick={simulateDoubleClick}>Double Click</Button>
            <Button onClick={simulateRightClick}>Right Click</Button>
          </div>
        )}

        {visible && (
          <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
            {keys.map((row, i) => (
              <div key={i} style={{ display: "flex", gap: "4px", justifyContent: "center" }}>
                {row.map((key) => (
                  <button
                    key={key}
                    onMouseEnter={() => handleMouseEnter(key)}
                    onMouseLeave={handleMouseLeave}
                    className="virtual-key"
                    style={{
                      padding: "12px",
                      borderRadius: "6px",
                      border: "1px solid #ccc",
                      backgroundColor: dwellKey === key ? "#cce4ff" : "#f9f9f9"
                    }}
                  >
                    {key === "Space" ? "␣" : key === "Back" ? "←" : key}
                  </button>
                ))}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
